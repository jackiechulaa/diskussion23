// src/pages/ThreadListPage.js
import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { ThreadContext } from "../contexts/ThreadContext";
import "../styles/ThreadListPage.css";

const ThreadListPage = () => {
  const { threads, loading, error } = useContext(ThreadContext);

  if (loading) return <div className="loading">Laddar trådar...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="thread-list-container">
      <h1>Diskussionstrådar</h1>
      <Link to="/create" className="create-thread-btn">
        Skapa ny tråd
      </Link>

      <div className="thread-list">
        {threads.length === 0 ? (
          <p>Inga trådar tillgängliga. Skapa den första!</p>
        ) : (
          threads.map((thread) => (
            <div className="thread-item" key={thread.id}>
              <h2>
                <Link to={`/thread/${thread.id}`}>{thread.title}</Link>
              </h2>
              <p className="thread-date">
                {new Date(thread.created_at).toLocaleString("sv-SE")}
              </p>
              <p className="thread-preview">
                {thread.content.length > 100
                  ? `${thread.content.substring(0, 100)}...`
                  : thread.content}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ThreadListPage;
