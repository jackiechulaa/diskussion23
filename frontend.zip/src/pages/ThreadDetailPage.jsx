import React, { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import "../styles/ThreadDetailPage.css";

const ThreadDetailPage = () => {
  const { id } = useParams();
  const [thread, setThread] = useState(null);
  const [replies, setReplies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [newReply, setNewReply] = useState("");

  // 1️⃣ Flytta `fetchThreadDetails` inuti komponenten
  const fetchThreadDetails = useCallback(async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `http://localhost:5000/api/threads/${id}`
      );
      setThread(response.data.thread);
      setReplies(response.data.replies);
      setError(null);
    } catch (err) {
      setError("Ett fel uppstod vid hämtning av tråden");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [id]); // 2️⃣ useCallback gör att funktionen inte skapas om id inte ändras

  // 3️⃣ Kör `fetchThreadDetails` när `id` ändras
  useEffect(() => {
    fetchThreadDetails();
  }, [fetchThreadDetails]);

  // Funktion för att skicka ett svar
  const handleSubmitReply = async (e) => {
    e.preventDefault();
    if (!newReply.trim()) return;

    try {
      const response = await axios.post(
        `http://localhost:5000/api/threads/${id}/replies`,
        { content: newReply }
      );
      setReplies([...replies, response.data]);
      setNewReply("");
    } catch (err) {
      setError("Ett fel uppstod vid skapande av svar");
      console.error(err);
    }
  };

  if (loading) return <div className="loading">Laddar...</div>;
  if (error) return <div className="error">{error}</div>;
  if (!thread) return <div className="error">Tråden hittades inte</div>;

  return (
    <div className="thread-detail-container">
      <Link to="/" className="back-link">
        &larr; Tillbaka till trådar
      </Link>

      <div className="thread-header">
        <h1>{thread.title}</h1>
        <p className="thread-date">
          {new Date(thread.created_at).toLocaleString("sv-SE")}
        </p>
      </div>

      <div className="thread-content">
        <p>{thread.content}</p>
      </div>

      <div className="replies-section">
        <h2>Svar ({replies.length})</h2>

        {replies.length === 0 ? (
          <p>Inga svar än. Bli först att svara!</p>
        ) : (
          <div className="replies-list">
            {replies.map((reply) => (
              <div className="reply-item" key={reply.id}>
                <p className="reply-content">{reply.content}</p>
                <p className="reply-date">
                  {new Date(reply.created_at).toLocaleString("sv-SE")}
                </p>
              </div>
            ))}
          </div>
        )}

        <div className="reply-form">
          <h3>Lämna ett svar</h3>
          <form onSubmit={handleSubmitReply}>
            <textarea
              value={newReply}
              onChange={(e) => setNewReply(e.target.value)}
              placeholder="Skriv ditt svar här..."
              required
            />
            <button type="submit">Skicka svar</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ThreadDetailPage;