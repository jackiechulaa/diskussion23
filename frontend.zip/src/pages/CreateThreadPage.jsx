// src/pages/CreateThreadPage.js
import React, { useState, useContext } from "react";
import { useNavigate, Link } from "react-router-dom";
import { ThreadContext } from "../contexts/ThreadContext";
import "../styles/CreateThreadPage.css";

const CreateThreadPage = () => {
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [error, setError] = useState("");
  const { createThread } = useContext(ThreadContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!name.trim() || !content.trim()) {
      setError("Både titel och innehåll måste fyllas i");
      return;
    }

    try {
      await createThread(name, content);
      navigate("/");
    } catch (err) {
      setError("Ett fel uppstod vid skapande av tråden");
    }
  };

  return (
    <div className="create-thread-container">
      <Link to="/" className="back-link">
        &larr; Tillbaka till trådar
      </Link>

      <h1>Skapa ny diskussionstråd</h1>

      {/* Visar felmeddelande om det finns */}
      {error && <div className="error">{error}</div>}

      <form className="thread-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="title">Namn:</label>
          <input
            type="text"
            id="title"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ange en beskrivande titel..."
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="content">Innehåll:</label>
          <textarea
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Skriv ditt inlägg här..."
            rows="10"
            required
          />
        </div>

        <button type="submit" className="submit-btn">
          Skapa tråd
        </button>
      </form>
    </div>
  );
};

export default CreateThreadPage;
