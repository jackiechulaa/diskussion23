// src/App.js
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ThreadProvider } from "./contexts/ThreadContext";
import ThreadListPage from "./pages/ThreadListPage";
import ThreadDetailPage from "./pages/ThreadDetailPage";
import CreateThreadPage from "./pages/CreateThreadPage";
import "./styles/App.css";

function App() {
  return (
    <Router>
      <ThreadProvider>
        <div className="app-container">
          <header className="app-header">
            <h1 className="site-title">Diskussionsforum</h1>
          </header>
          <main className="main-content">
            <Routes>
              <Route path="/" element={<ThreadListPage />} />
              <Route path="/thread/:id" element={<ThreadDetailPage />} />
              <Route path="/create" element={<CreateThreadPage />} />
            </Routes>
          </main>
          <footer className="app-footer">
            <p>&copy; {new Date().getFullYear()} Diskussionsforum</p>
          </footer>
        </div>
      </ThreadProvider>
    </Router>
  );
}

export default App;
