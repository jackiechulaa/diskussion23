// src/contexts/ThreadContext.js
import React, { createContext, useState, useEffect } from "react";
import axios from "axios";

export const ThreadContext = createContext();

export const ThreadProvider = ({ children }) => {
  const [threads, setThreads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Hämta alla trådar
  const fetchThreads = async () => {
    try {
      setLoading(true);
      const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000";
      const response = await axios.get(`${API_URL}/api/threads`);
      setThreads(response.data);
      setError(null);
    } catch (err) {
      setError("Ett fel uppstod vid hämtning av trådar");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Skapa en ny tråd
  const createThread = async (title, content) => {
    try {
      const response = await axios.post("http://localhost:5000/api/threads", {
        title,
        content,
      });
      setThreads([response.data, ...threads]);
      return response.data;
    } catch (err) {
      setError("Ett fel uppstod vid skapande av tråd");
      console.error(err);
      throw err;
    }
  };

  // Hämta trådar när komponenten monteras
  useEffect(() => {
    fetchThreads();
  }, []);

  return (
    <ThreadContext.Provider
      value={{
        threads,
        loading,
        error,
        fetchThreads,
        createThread,
      }}
    >
      {children}
    </ThreadContext.Provider>
  );
};